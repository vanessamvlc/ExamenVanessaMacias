USE [master]
GO
/****** Object:  Database [PruebasDB]    Script Date: 05/12/2024 04:08:59 p. m. ******/
CREATE DATABASE [PruebasDB]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'PruebasDB', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL16.MSSQLSERVER\MSSQL\DATA\PruebasDB.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'PruebasDB_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL16.MSSQLSERVER\MSSQL\DATA\PruebasDB_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
 WITH CATALOG_COLLATION = DATABASE_DEFAULT, LEDGER = OFF
GO
ALTER DATABASE [PruebasDB] SET COMPATIBILITY_LEVEL = 160
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [PruebasDB].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [PruebasDB] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [PruebasDB] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [PruebasDB] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [PruebasDB] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [PruebasDB] SET ARITHABORT OFF 
GO
ALTER DATABASE [PruebasDB] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [PruebasDB] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [PruebasDB] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [PruebasDB] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [PruebasDB] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [PruebasDB] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [PruebasDB] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [PruebasDB] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [PruebasDB] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [PruebasDB] SET  DISABLE_BROKER 
GO
ALTER DATABASE [PruebasDB] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [PruebasDB] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [PruebasDB] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [PruebasDB] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [PruebasDB] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [PruebasDB] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [PruebasDB] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [PruebasDB] SET RECOVERY FULL 
GO
ALTER DATABASE [PruebasDB] SET  MULTI_USER 
GO
ALTER DATABASE [PruebasDB] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [PruebasDB] SET DB_CHAINING OFF 
GO
ALTER DATABASE [PruebasDB] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [PruebasDB] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [PruebasDB] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [PruebasDB] SET ACCELERATED_DATABASE_RECOVERY = OFF  
GO
EXEC sys.sp_db_vardecimal_storage_format N'PruebasDB', N'ON'
GO
ALTER DATABASE [PruebasDB] SET QUERY_STORE = ON
GO
ALTER DATABASE [PruebasDB] SET QUERY_STORE (OPERATION_MODE = READ_WRITE, CLEANUP_POLICY = (STALE_QUERY_THRESHOLD_DAYS = 30), DATA_FLUSH_INTERVAL_SECONDS = 900, INTERVAL_LENGTH_MINUTES = 60, MAX_STORAGE_SIZE_MB = 1000, QUERY_CAPTURE_MODE = AUTO, SIZE_BASED_CLEANUP_MODE = AUTO, MAX_PLANS_PER_QUERY = 200, WAIT_STATS_CAPTURE_MODE = ON)
GO
USE [PruebasDB]
GO
/****** Object:  Table [dbo].[CatBrands]    Script Date: 05/12/2024 04:08:59 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CatBrands](
	[idBrand] [int] IDENTITY(1,1) NOT NULL,
	[namee] [varchar](200) NULL,
	[averagePrice] [decimal](30, 2) NULL,
PRIMARY KEY CLUSTERED 
(
	[idBrand] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[CatModels]    Script Date: 05/12/2024 04:08:59 p. m. ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CatModels](
	[idModel] [int] IDENTITY(1,1) NOT NULL,
	[idBrand] [int] NULL,
	[namee] [varchar](200) NULL,
	[averagePrice] [decimal](30, 2) NULL,
PRIMARY KEY CLUSTERED 
(
	[idModel] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[CatBrands] ON 
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (62, N'Acura', CAST(702109.50 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (63, N'Audi', CAST(630759.47 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (64, N'Bentley', CAST(3342575.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (65, N'BMW', CAST(858702.05 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (66, N'Buick', CAST(290371.89 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (67, N'Cadillac', CAST(479268.22 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (68, N'Chevrolet', CAST(252685.55 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (69, N'Chrysler', CAST(191894.69 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (70, N'Dodge', CAST(209228.76 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (71, N'FAW', CAST(52707.14 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (72, N'Ferrari', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (73, N'Fiat', CAST(107028.18 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (74, N'Ford', CAST(176244.84 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (75, N'GMC', CAST(341265.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (76, N'Honda', CAST(236689.53 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (77, N'Infiniti', CAST(457639.27 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (78, N'Jaguar', CAST(854875.09 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (79, N'Jeep', CAST(260805.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (80, N'Lamborghini', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (81, N'Land Rover', CAST(823132.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (82, N'Lincoln', CAST(419551.17 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (83, N'Maserati', CAST(1598631.25 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (84, N'Mastretta', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (85, N'Mazda', CAST(235162.91 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (86, N'Mercedes Benz', CAST(874873.41 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (87, N'Mitsubishi', CAST(205150.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (88, N'Nissan', CAST(251351.33 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (89, N'Peugeot', CAST(241946.25 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (90, N'Porsche', CAST(901843.14 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (91, N'RAM', CAST(156775.33 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (92, N'Renault', CAST(150916.05 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (93, N'Rolls Royce', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (94, N'Seat', CAST(203512.40 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (95, N'Smart', CAST(122601.80 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (96, N'Subaru', CAST(269824.78 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (97, N'Suzuki', CAST(167157.23 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (98, N'Toyota', CAST(263356.90 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (99, N'Volkswagen', CAST(224084.59 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (100, N'Volvo', CAST(415593.25 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (101, N'Alfa Romeo', CAST(566127.25 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (102, N'Hummer', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (103, N'Hyundai', CAST(216107.36 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (104, N'Isuzu', CAST(317797.60 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (105, N'McLaren', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (106, N'Mercury', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (107, N'Cbo', CAST(149387.50 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (108, N'Pontiac', CAST(66382.82 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (109, N'Saab', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (110, N'Aston Martin', CAST(2677625.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (111, N'Lotus', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (112, N'MG', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (113, N'Tesla', CAST(1488137.33 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (114, N'Abarth', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (115, N'KIA', CAST(369233.30 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (116, N'Mini Cooper', CAST(290547.44 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (117, N'Baic', CAST(311875.80 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (118, N'JAC', CAST(363027.20 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (119, N'HINO', CAST(977124.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (120, N'International', CAST(717030.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (121, N'UAZ', CAST(542000.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatBrands] ([idBrand], [namee], [averagePrice]) VALUES (122, N'Zacua', CAST(0.00 AS Decimal(30, 2)))
GO
SET IDENTITY_INSERT [dbo].[CatBrands] OFF
GO
SET IDENTITY_INSERT [dbo].[CatModels] ON 
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (678, 62, N'ILX', CAST(303176.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (679, 62, N'MDX', CAST(448193.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (680, 62, N'RDX', CAST(395753.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (681, 62, N'RLX', CAST(453100.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (682, 62, N'TL', CAST(247225.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (683, 62, N'TSX', CAST(232533.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (684, 63, N'A1', CAST(260696.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (685, 63, N'A3', CAST(255299.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (686, 63, N'A4', CAST(299412.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (687, 63, N'A5', CAST(511069.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (688, 63, N'A6', CAST(499782.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (689, 63, N'A7', CAST(1040891.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (690, 63, N'A8', CAST(1059155.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (691, 63, N'Q3', CAST(454949.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (692, 63, N'Q5', CAST(532993.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (693, 63, N'Q7', CAST(593487.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (694, 63, N'R8', CAST(1463936.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (695, 63, N'TT', CAST(498670.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (696, 64, N'Continental', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (697, 64, N'Flying Spur', CAST(3968000.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (698, 64, N'Continental GT', CAST(4498875.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (699, 64, N'Mulsanne', CAST(3968000.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (700, 65, N'X6', CAST(898716.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (701, 66, N'Enclave', CAST(583200.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (702, 66, N'Encore', CAST(335845.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (703, 66, N'LaCrosse', CAST(419233.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (704, 66, N'Regal', CAST(352460.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (705, 66, N'Verano', CAST(325409.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (706, 67, N'ATS', CAST(737342.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (707, 67, N'CTS', CAST(636500.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (708, 67, N'SRX', CAST(422207.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (709, 68, N'Aveo', CAST(128557.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (710, 68, N'Camaro', CAST(507271.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (711, 68, N'Cheyenne', CAST(345435.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (712, 68, N'Colorado', CAST(284984.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (713, 68, N'Cruze', CAST(227283.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (714, 68, N'Malibu', CAST(238000.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (715, 68, N'Matiz', CAST(56821.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (716, 68, N'Sonic', CAST(146029.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (717, 68, N'Spark', CAST(144415.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (718, 68, N'Suburban', CAST(572851.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (719, 68, N'Tahoe', CAST(519019.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (720, 68, N'Tornado', CAST(152882.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (721, 68, N'Traverse', CAST(412188.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (722, 68, N'Trax', CAST(236175.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (723, 69, N'Chrysler 200', CAST(283907.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (724, 69, N'Chrysler 300', CAST(366584.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (725, 69, N'Town', CAST(317192.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (726, 70, N'Attitude', CAST(121966.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (727, 70, N'Avenger', CAST(134104.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (728, 70, N'Challenger', CAST(630386.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (729, 70, N'Charger', CAST(376721.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (730, 70, N'Dart', CAST(278366.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (731, 70, N'Durango', CAST(294664.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (732, 70, N'Journey', CAST(274681.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (733, 71, N'GF250 ', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (734, 71, N'GF6000', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (735, 71, N'GF70', CAST(112600.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (736, 71, N'GF7000', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (737, 71, N'GF8', CAST(103500.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (738, 71, N'GF900', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (739, 72, N'California', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (740, 72, N'FF', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (741, 73, N'Ducato', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (742, 73, N'F500', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (743, 73, N'Palio', CAST(130515.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (744, 73, N'Palio Adventure', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (745, 73, N'Punto', CAST(181600.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (746, 73, N'Palio Strada', CAST(110558.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (747, 73, N'Strada Adventure', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (748, 73, N'Uno', CAST(161305.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (749, 74, N'E-150', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (750, 74, N'E-350', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (751, 74, N'Eco Sport', CAST(189465.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (752, 74, N'Edge', CAST(408952.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (753, 74, N'Escape', CAST(226759.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (754, 74, N'Expedition', CAST(436655.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (755, 74, N'Explorer', CAST(318270.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (756, 74, N'F-150', CAST(268727.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (757, 74, N'F-250', CAST(201785.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (758, 74, N'F-350', CAST(287341.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (759, 74, N'F-450', CAST(320575.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (760, 74, N'F-550', CAST(370436.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (761, 74, N'Fiesta', CAST(138747.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (762, 74, N'Focus', CAST(189192.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (763, 74, N'Fusion', CAST(252518.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (764, 74, N'Ikon hatchback', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (765, 74, N'Lobo', CAST(363385.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (766, 74, N'Lobo Raptor', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (767, 74, N'Mustang', CAST(367921.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (768, 74, N'Ranger', CAST(210497.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (769, 74, N'Transit', CAST(278628.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (770, 75, N'Acadia', CAST(400347.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (771, 75, N'Sierra', CAST(464248.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (772, 75, N'Terrain', CAST(444504.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (773, 75, N'Yukon', CAST(556491.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (774, 76, N'Accord', CAST(221035.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (775, 76, N'City', CAST(166870.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (776, 76, N'Civic', CAST(185562.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (777, 76, N'CR-V', CAST(247293.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (778, 76, N'CR-Z', CAST(209033.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (779, 76, N'Crosstour', CAST(255420.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (780, 76, N'Fit', CAST(142098.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (781, 76, N'Odyssey', CAST(343033.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (782, 76, N'Pilot', CAST(331339.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (783, 76, N'Ridge Line', CAST(253687.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (784, 77, N'Q60', CAST(673900.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (785, 77, N'Q70', CAST(651500.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (786, 77, N'QX60', CAST(665011.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (787, 77, N'QX70', CAST(660861.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (788, 77, N'QX80', CAST(951850.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (789, 78, N'F', CAST(1484528.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (790, 78, N'XF', CAST(791032.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (791, 78, N'XJ', CAST(606150.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (792, 78, N'XKR', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (793, 79, N'Cherokee', CAST(456109.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (794, 79, N'Compass', CAST(263629.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (795, 79, N'Grand Cherokee', CAST(562944.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (796, 79, N'Patriot', CAST(185558.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (797, 79, N'Wrangler', CAST(396757.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (798, 80, N'Aventador', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (799, 80, N'Gallardo', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (800, 81, N'Defender', CAST(923797.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (801, 81, N'Discovery', CAST(1019830.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (802, 81, N'LR2', CAST(482077.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (803, 81, N'Range Rover', CAST(1762459.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (804, 82, N'Mark LT', CAST(318420.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (805, 82, N'MKS', CAST(309425.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (806, 82, N'MKX', CAST(429064.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (807, 82, N'MKZ', CAST(417642.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (808, 82, N'Navigator', CAST(578993.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (809, 83, N'Gran Cabrio', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (810, 83, N'Gran Turismo', CAST(2810925.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (811, 83, N'Quattroporte', CAST(2263000.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (812, 84, N'MXT', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (813, 85, N'Mazda 2', CAST(183824.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (814, 85, N'Mazda 3', CAST(192010.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (815, 85, N'Mazda 5', CAST(135327.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (816, 85, N'Mazda 6', CAST(194683.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (817, 85, N'CX9', CAST(383370.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (818, 85, N'MX5', CAST(261504.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (819, 86, N'Clase A', CAST(463191.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (820, 86, N'Clase B', CAST(239151.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (821, 86, N'Clase C', CAST(672744.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (822, 86, N'Clase CLA', CAST(488793.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (823, 86, N'Clase CLS', CAST(767931.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (824, 86, N'Clase E', CAST(727529.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (825, 86, N'Clase G', CAST(2193198.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (826, 86, N'Clase GL', CAST(696475.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (827, 86, N'Clase GLK', CAST(351929.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (828, 86, N'Clase ML', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (829, 86, N'Clase S', CAST(2556844.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (830, 86, N'Clase SL', CAST(1584684.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (831, 86, N'Clase SLK', CAST(530838.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (832, 86, N'Clase SLS AMG', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (833, 86, N'Viano', CAST(433878.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (834, 87, N'ASX', CAST(209442.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (835, 87, N'L200', CAST(215532.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (836, 87, N'Lancer', CAST(153796.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (837, 87, N'Montero', CAST(350767.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (838, 87, N'Outlander', CAST(236435.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (839, 88, N'370Z', CAST(440869.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (840, 88, N'Altima', CAST(184092.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (841, 88, N'Armada', CAST(340681.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (842, 88, N'Frontier LE', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (843, 88, N'Frontier XE', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (844, 88, N'Juke', CAST(226880.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (845, 88, N'March', CAST(130214.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (846, 88, N'Maxima', CAST(295525.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (847, 88, N'Murano', CAST(262091.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (848, 88, N'Note', CAST(184206.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (849, 88, N'NP300', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (850, 88, N'Pathfinder', CAST(342334.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (851, 88, N'Rogue', CAST(175936.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (852, 88, N'Sentra', CAST(157613.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (853, 88, N'Titan', CAST(251044.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (854, 88, N'Tsuru', CAST(78120.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (855, 88, N'Urvan', CAST(239288.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (856, 88, N'Versa', CAST(159324.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (857, 88, N'X Trail', CAST(260731.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (858, 89, N'207 CC', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (859, 89, N'208', CAST(201530.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (860, 89, N'3008', CAST(336527.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (861, 89, N'301', CAST(184431.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (862, 89, N'308', CAST(245043.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (863, 89, N'308 CC', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (864, 89, N'508', CAST(314191.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (865, 89, N'Manager', CAST(342506.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (866, 89, N'RCZ', CAST(404630.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (867, 90, N'911', CAST(1371633.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (868, 90, N'Boxster', CAST(745149.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (869, 90, N'Cayenne', CAST(941314.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (870, 90, N'Cayman', CAST(743222.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (871, 90, N'Panamera', CAST(1500840.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (872, 91, N'Bighorn', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (873, 91, N'Crew Cab', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (874, 91, N'Hemi Sport', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (875, 91, N'Power Wagon', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (876, 91, N'Regular Cab R/T', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (877, 91, N'Regular Cab SLT', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (878, 91, N'ST', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (879, 92, N'Duster', CAST(209145.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (880, 92, N'Fluence', CAST(169802.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (881, 92, N'Kangoo', CAST(60585.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (882, 92, N'Koleos', CAST(257672.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (883, 92, N'Safrane', CAST(181925.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (884, 92, N'Sandero', CAST(126814.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (885, 92, N'Stepway', CAST(167890.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (886, 93, N'Ghost', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (887, 93, N'Phantom', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (888, 94, N'Altea', CAST(141055.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (889, 94, N'Freetrack', CAST(164408.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (890, 94, N'Ibiza', CAST(156859.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (891, 94, N'Leon', CAST(234543.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (892, 94, N'Toledo', CAST(191512.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (893, 95, N'Brabus', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (894, 95, N'Fortwo', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (895, 96, N'Forester', CAST(307996.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (896, 96, N'Impreza', CAST(232322.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (897, 96, N'Legacy', CAST(231704.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (898, 96, N'Outback', CAST(294950.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (899, 96, N'WRX', CAST(344748.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (900, 96, N'XV', CAST(310570.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (901, 97, N'Grand Vitara', CAST(197100.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (902, 97, N'Kizashi', CAST(241536.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (903, 97, N'S-Cross', CAST(235612.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (904, 97, N'Swift', CAST(171901.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (905, 97, N'SX 4 Crossover', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (906, 97, N'SX 4 Sedan ', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (907, 98, N'Avanza', CAST(161502.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (908, 98, N'Camry', CAST(260490.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (909, 98, N'Corolla', CAST(180456.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (910, 98, N'FJ Cruiser', CAST(301680.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (911, 98, N'Hiace', CAST(226078.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (912, 98, N'Highlander', CAST(375704.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (913, 98, N'Hilux', CAST(209308.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (914, 98, N'Land Cruiser', CAST(700584.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (915, 98, N'Prius', CAST(281072.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (916, 98, N'Rav4', CAST(254634.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (917, 98, N'Sequoia', CAST(490790.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (918, 98, N'Sienna', CAST(329930.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (919, 98, N'Tacoma', CAST(352954.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (920, 98, N'Tundra', CAST(402731.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (921, 99, N'Amarok', CAST(341421.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (922, 99, N'Beetle', CAST(174920.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (923, 99, N'CC', CAST(299380.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (924, 99, N'Clasico', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (925, 99, N'CrossFox', CAST(158882.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (926, 99, N'Gol', CAST(115926.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (927, 99, N'Gol Sedan', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (928, 99, N'Jetta Clasico', CAST(100096.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (929, 99, N'Passat', CAST(216005.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (930, 99, N'Polo', CAST(165026.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (931, 99, N'Saveiro', CAST(199246.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (932, 99, N'Tiguan', CAST(317202.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (933, 99, N'Touareg', CAST(483431.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (934, 99, N'Vento', CAST(175146.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (935, 100, N'S60', CAST(372106.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (936, 100, N'S80', CAST(256982.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (937, 100, N'V40', CAST(332068.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (938, 100, N'V60', CAST(460872.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (939, 100, N'XC60', CAST(498311.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (940, 100, N'XC90', CAST(587919.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (941, 62, N'RL', CAST(239050.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (942, 62, N'ZDX', CAST(405550.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (943, 101, N'147', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (944, 101, N'166', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (945, 101, N'4C', CAST(1081850.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (946, 101, N'Giulietta', CAST(457240.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (947, 101, N'MiTo', CAST(345862.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (948, 65, N'i3', CAST(671180.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (949, 65, N'i8', CAST(2195133.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (950, 65, N'Serie 1', CAST(277295.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (951, 65, N'Serie 2', CAST(584746.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (952, 65, N'Serie 3', CAST(415477.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (953, 65, N'Serie 4', CAST(758820.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (954, 65, N'Serie 5', CAST(553739.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (955, 65, N'Serie 6', CAST(891559.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (956, 65, N'Serie 7', CAST(1132673.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (957, 65, N'Serie 8', CAST(2179900.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (958, 65, N'X1', CAST(373718.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (959, 65, N'X3', CAST(398124.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (960, 65, N'X4', CAST(730075.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (961, 65, N'X5', CAST(796909.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (962, 65, N'Z', CAST(479845.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (963, 66, N'LeSabre', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (964, 66, N'Rendezvous', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (965, 66, N'Terraza', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (966, 67, N'BLS', CAST(113350.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (967, 67, N'DTS', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (968, 67, N'STS', CAST(192210.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (969, 68, N'3500', CAST(253193.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (970, 68, N'Astra', CAST(79910.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (971, 68, N'Avalanche', CAST(289500.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (972, 68, N'Blazer', CAST(697900.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (973, 68, N'Captiva', CAST(204955.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (974, 68, N'Chevy', CAST(61489.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (975, 68, N'Cobalt', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (976, 68, N'Corsa', CAST(61780.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (977, 68, N'Corvette', CAST(811984.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (978, 68, N'Epica', CAST(93033.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (979, 68, N'Equinox', CAST(340491.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (980, 68, N'Express', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (981, 68, N'HHR', CAST(94141.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (982, 68, N'Impala', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (983, 68, N'Meriva', CAST(62754.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (984, 68, N'Optra', CAST(78281.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (985, 68, N'S10', CAST(306100.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (986, 68, N'SS R', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (987, 68, N'Sonora', CAST(104450.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (988, 68, N'Tracker', CAST(91066.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (989, 68, N'Trailblazer', CAST(101966.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (990, 68, N'Uplander', CAST(113130.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (991, 68, N'Vectra', CAST(90933.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (992, 68, N'Venture', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (993, 68, N'Zafira', CAST(90400.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (994, 69, N'Aspen', CAST(174762.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (995, 69, N'Avenger', CAST(135956.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (996, 69, N'Cirrus', CAST(126755.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (997, 69, N'Crossfire', CAST(149550.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (998, 69, N'Dart', CAST(220718.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (999, 69, N'Grand Voyager', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1000, 69, N'PT Cruiser', CAST(83738.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1001, 69, N'Pacifica', CAST(521537.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1002, 69, N'Sebring', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1003, 69, N'Voyager', CAST(113932.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1004, 70, N'Atos', CAST(61385.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1005, 70, N'Caliber', CAST(113914.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1006, 70, N'Dakota', CAST(143623.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1007, 70, N'Grand Caravan', CAST(497464.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1008, 70, N'H 100', CAST(173933.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1009, 70, N'i10', CAST(85793.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1010, 70, N'Intrepid', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1011, 70, N'Magnum', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1012, 70, N'Neon', CAST(254521.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1013, 70, N'Nitro', CAST(157452.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1014, 70, N'RAM', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1015, 70, N'Stratus', CAST(60283.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1016, 70, N'Van 1000', CAST(97850.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1017, 70, N'Verna', CAST(50766.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1018, 70, N'Viper', CAST(890387.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1019, 72, N'430', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1020, 72, N'458', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1021, 72, N'599', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1022, 72, N'612', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1023, 72, N'F12', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1024, 72, N'La Ferrari', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1025, 73, N'500', CAST(221640.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1026, 73, N'Albea', CAST(75400.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1027, 73, N'Bravo', CAST(117000.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1028, 73, N'Grande Punto', CAST(76657.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1029, 73, N'Linea', CAST(118000.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1030, 73, N'Panda', CAST(77908.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1031, 73, N'Stilo', CAST(97800.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1032, 74, N'Bronco', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1033, 74, N'Club Wagon', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1034, 74, N'Econoline', CAST(171225.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1035, 74, N'Escort', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1036, 74, N'Excursion', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1037, 74, N'F-100', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1038, 74, N'Five Hundred', CAST(82700.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1039, 74, N'Freestar', CAST(100350.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1040, 74, N'Ikon', CAST(98350.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1041, 74, N'Interceptor', CAST(338475.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1042, 74, N'Ka', CAST(45233.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1043, 74, N'Mondeo', CAST(69310.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1044, 74, N'Taurus', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1045, 74, N'Windstar', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1046, 75, N'Canyon', CAST(182000.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1047, 75, N'Savana', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1048, 76, N'Element', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1049, 76, N'Passport', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1050, 102, N'H1', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1051, 102, N'H2', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1052, 102, N'H3', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1053, 103, N'Atos', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1054, 103, N'Attitude', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1055, 103, N'Elantra', CAST(224769.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1056, 103, N'Grand i10', CAST(136722.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1057, 103, N'H100', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1058, 103, N'ix35', CAST(200520.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1059, 103, N'Sonata', CAST(300443.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1060, 103, N'Verna', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1061, 77, N'FX', CAST(500350.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1062, 77, N'FX 50', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1063, 77, N'G', CAST(357625.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1064, 77, N'I30', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1065, 77, N'JX', CAST(430200.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1066, 77, N'Q 45', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1067, 77, N'Q50', CAST(519076.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1068, 77, N'QX', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1069, 104, N'Rodeo', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1070, 78, N'S-Type', CAST(150450.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1071, 78, N'X-Type', CAST(122725.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1072, 78, N'XK', CAST(615857.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1073, 79, N'CJ5', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1074, 79, N'Commander', CAST(157492.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1075, 79, N'Grand Wagoneer', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1076, 79, N'Liberty', CAST(188641.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1077, 80, N'Asterion', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1078, 80, N'Huracan', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1079, 80, N'Veneno', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1080, 81, N'Evoque', CAST(690500.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1081, 81, N'Freelander', CAST(108600.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1082, 81, N'LR3', CAST(209962.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1083, 81, N'LR4', CAST(505630.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1084, 82, N'Aviator', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1085, 82, N'LS', CAST(97000.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1086, 82, N'MKC', CAST(499270.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1087, 82, N'Town Car', CAST(122750.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1088, 82, N'Zephyr', CAST(113700.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1089, 85, N'CX7', CAST(179026.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1090, 85, N'Tribute', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1091, 105, N'MP4-12C', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1092, 86, N'Clase CL', CAST(937917.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1093, 86, N'Clase CLK', CAST(263046.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1094, 86, N'Clase M', CAST(578767.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1095, 86, N'Clase R', CAST(316430.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1096, 86, N'Sprinter', CAST(476619.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1097, 86, N'Vito', CAST(219848.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1098, 106, N'Grand Marquis', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1099, 106, N'Mariner', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1100, 106, N'Milan', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1101, 106, N'Mountaineer', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1102, 107, N'CBO', CAST(125775.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1103, 87, N'Eclipse', CAST(142225.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1104, 87, N'Endeavor', CAST(146240.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1105, 87, N'Galant', CAST(79163.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1106, 87, N'Grandis', CAST(125200.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1107, 88, N'240SX', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1108, 88, N'350Z', CAST(189600.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1109, 88, N'Aprio', CAST(69450.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1110, 88, N'Cabstar', CAST(294305.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1111, 88, N'Estacas', CAST(169790.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1112, 88, N'NV2500', CAST(303385.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1113, 88, N'Platina', CAST(58266.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1114, 88, N'Quest', CAST(128606.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1115, 88, N'Tiida', CAST(111954.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1116, 88, N'Xterra', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1117, 89, N'206', CAST(63464.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1118, 89, N'307', CAST(81807.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1119, 89, N'406', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1120, 89, N'407', CAST(93361.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1121, 89, N'607', CAST(103000.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1122, 89, N'Grand Raid', CAST(89709.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1123, 89, N'Partner', CAST(172626.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1124, 108, N'G-3', CAST(70855.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1125, 108, N'G-4', CAST(66766.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1126, 108, N'G-5', CAST(88000.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1127, 108, N'G-6', CAST(95266.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1128, 108, N'Grand Am', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1129, 108, N'Grand Prix', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1130, 108, N'Matiz', CAST(44885.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1131, 108, N'Montana', CAST(107887.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1132, 108, N'Solstice', CAST(144780.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1133, 108, N'Sunfire', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1134, 108, N'Torrent', CAST(111772.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1135, 90, N'918 Spyder', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1136, 92, N'Clio', CAST(108000.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1137, 92, N'Euroclio', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1138, 92, N'Laguna', CAST(66600.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1139, 92, N'Megane', CAST(80572.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1140, 92, N'Scala', CAST(94237.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1141, 92, N'Scenic', CAST(73400.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1142, 92, N'Trafic Panel', CAST(171911.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1143, 93, N'Wraith', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1144, 109, N'9-2', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1145, 109, N'9-3', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1146, 109, N'90', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1147, 94, N'Alhambra', CAST(101700.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1148, 94, N'Cordoba', CAST(82635.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1149, 94, N'Exeo', CAST(211150.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1150, 95, N'Forfour', CAST(219000.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1151, 96, N'B9 Tribeca', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1152, 96, N'Tribeca', CAST(235850.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1153, 97, N'Aerio', CAST(62600.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1154, 97, N'SX4', CAST(134540.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1155, 97, N'Vitara', CAST(289756.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1156, 97, N'XL7', CAST(137360.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1157, 98, N'4Runner', CAST(155264.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1158, 98, N'Matrix', CAST(109200.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1159, 98, N'Rush', CAST(113750.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1160, 98, N'Solara', CAST(113700.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1161, 98, N'Tercel', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1162, 98, N'Yaris', CAST(143268.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1163, 99, N'Bora', CAST(124253.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1164, 99, N'Derby', CAST(63075.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1165, 99, N'Cabrio', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1166, 99, N'Caribe', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1167, 99, N'Golf', CAST(252992.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1168, 62, N'TLX', CAST(478290.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1169, 101, N'Spider', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1170, 87, N'Mirage', CAST(167900.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1171, 100, N'C30', CAST(171037.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1172, 110, N'DBS', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1173, 110, N'DB9', CAST(3859500.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1174, 110, N'Lagonda', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1175, 110, N'Vantage', CAST(2720250.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1176, 110, N'Vanquish', CAST(5580000.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1177, 110, N'Rapide', CAST(3906000.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1178, 111, N'Elise', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1179, 111, N'Exige', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1180, 111, N'Evora', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1181, 112, N'MG3', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1182, 112, N'MG6', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1183, 113, N'S', CAST(2137587.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1184, 113, N'X', CAST(2326825.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1185, 114, N'500', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1186, 115, N'Forte', CAST(270506.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1187, 115, N'Sorento', CAST(440080.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1188, 115, N'Sportage', CAST(368219.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1189, 92, N'Logan', CAST(174524.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1190, 90, N'Macan', CAST(1010744.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1191, 67, N'Escalade', CAST(689650.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1192, 68, N'Silverado', CAST(178660.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1193, 116, N'Mini', CAST(343512.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1194, 116, N'Mini S', CAST(323112.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1195, 116, N'Coupe', CAST(301593.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1196, 116, N'Convertible', CAST(290934.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1197, 116, N'Roadster', CAST(313133.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1198, 116, N'Countryman', CAST(331884.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1199, 116, N'Paceman', CAST(349017.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1200, 116, N'John Cooper Works', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1201, 89, N'207', CAST(109263.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1202, 89, N'2008', CAST(286114.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1203, 100, N'V50', CAST(126000.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1204, 100, N'C70', CAST(304557.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1205, 100, N'S40', CAST(149377.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1206, 72, N'488', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1207, 103, N'Tucson', CAST(343817.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1208, 85, N'CX5', CAST(321758.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1209, 76, N'HR-V', CAST(311173.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1210, 85, N'CX3', CAST(295390.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1211, 86, N'Clase GLA', CAST(485557.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1212, 86, N'Clase GLC', CAST(723551.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1213, 86, N'Clase GLE', CAST(1368918.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1214, 86, N'AMG GT', CAST(2718345.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1215, 109, N'Aero', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1216, 97, N'Ciaz', CAST(216360.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1217, 86, N'Clase V', CAST(844904.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1218, 99, N'Up', CAST(163962.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1219, 115, N'Optima', CAST(360900.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1220, 115, N'Rio', CAST(223032.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1221, 88, N'Leaf', CAST(531990.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1222, 63, N'S3', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1223, 113, N'3', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1224, 92, N'Twizy', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1225, 115, N'Soul', CAST(275188.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1226, 68, N'Volt', CAST(658880.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1227, 74, N'Figo', CAST(171262.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1228, 117, N'D20', CAST(169088.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1229, 117, N'X25', CAST(237345.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1230, 97, N'Ignis', CAST(197956.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1231, 103, N'Creta', CAST(189895.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1232, 118, N'SEI2', CAST(383714.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1233, 118, N'SEI3', CAST(346922.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1234, 119, N'Serie 500', CAST(1142796.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1235, 62, N'NSX', CAST(3818225.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1236, 63, N'Q2', CAST(541153.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1237, 117, N'BJ40', CAST(520166.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1238, 64, N'Bentayga', CAST(4278000.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1239, 65, N'Serie Z', CAST(555130.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1240, 66, N'Envision', CAST(597200.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1241, 67, N'XT5', CAST(775655.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1242, 107, N'CBO', CAST(173000.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1243, 74, N'Transit Van', CAST(498596.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1244, 68, N'Beat', CAST(167757.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1245, 68, N'Bolt EV', CAST(695333.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1246, 68, N'Cargo Van', CAST(361027.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1247, 68, N'Cavalier', CAST(272971.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1248, 68, N'Express Cutaway', CAST(326457.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1249, 68, N'Express Van', CAST(439228.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1250, 68, N'S-10', CAST(270122.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1251, 68, N'Sierra', CAST(580652.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1252, 68, N'Silverado 1500', CAST(363866.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1253, 68, N'Silverado 2500', CAST(404665.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1254, 68, N'Silverado 3500', CAST(402850.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1255, 103, N'ACCENT', CAST(240760.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1256, 103, N'SANTA FE', CAST(533277.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1257, 77, N'QX30', CAST(632983.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1258, 120, N'CITYSTAR', CAST(717030.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1259, 78, N'F Pace', CAST(1300675.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1260, 78, N'XE', CAST(970270.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1261, 115, N'NIRO', CAST(452475.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1262, 81, N'Discovery Sport', CAST(772785.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1263, 81, N'Range Rover Sport', CAST(1326131.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1264, 82, N'Continental', CAST(1196750.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1265, 83, N'Ghibli', CAST(1320600.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1266, 86, N'Cargo Van', CAST(504323.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1267, 86, N'Chasis Cabina', CAST(367440.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1268, 86, N'Clase GLS', CAST(1801912.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1269, 86, N'Clase SLC', CAST(835650.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1270, 86, N'Clase SLS', CAST(3415950.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1271, 86, N'Crew Cab', CAST(429587.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1272, 88, N'Chasis Cabina', CAST(185095.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1273, 88, N'Doble Cabina', CAST(223808.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1274, 88, N'Frontier', CAST(347004.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1275, 88, N'GT-R', CAST(2180600.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1276, 88, N'Kicks', CAST(311277.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1277, 88, N'Pick Up', CAST(214570.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1278, 89, N'Partner Maxi', CAST(221392.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1279, 92, N'Captur', CAST(307844.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1280, 92, N'Kangoo Express', CAST(175550.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1281, 92, N'Twitzy Z.E.', CAST(250300.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1282, 94, N'ATECA', CAST(406112.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1283, 96, N'BRZ', CAST(470283.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1284, 121, N'Hunter', CAST(542000.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1285, 99, N'Caddy', CAST(237534.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1286, 99, N'Crafter', CAST(426691.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1287, 99, N'Crafter Pasajeros', CAST(549187.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1288, 99, N'Cross Golf', CAST(277150.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1289, 99, N'Jetta Nuevo', CAST(214175.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1290, 99, N'Transporter', CAST(332755.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1291, 100, N'S90', CAST(1042940.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1292, 73, N'Ducato Van', CAST(285908.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1293, 73, N'Mobi', CAST(165188.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1294, 115, N'Stinger', CAST(647283.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1295, 103, N'Ioniq', CAST(438900.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1296, 98, N'C-HR', CAST(367400.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1297, 79, N'Renegade', CAST(396920.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1298, 103, N'Starex', CAST(416400.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1299, 115, N'Sedona', CAST(654650.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1300, 94, N'Arona', CAST(345150.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1301, 91, N'Ram 1500', CAST(453421.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1302, 91, N'Ram 2500', CAST(439179.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1303, 91, N'Ram 4000', CAST(379308.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1304, 70, N'H 100 Wagon', CAST(223850.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1305, 74, N'Econoline Wagon', CAST(291950.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1306, 104, N'ELF 200', CAST(380933.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1307, 104, N'ELF 400', CAST(481755.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1308, 104, N'ELF 300', CAST(426500.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1309, 116, N'Clubman', CAST(361742.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1310, 70, N'GTS', CAST(151950.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1311, 91, N'Ram Promaster', CAST(389350.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1312, 95, N'Cabrio', CAST(212563.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1313, 95, N'Coupé', CAST(181446.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1314, 70, N'Vision', CAST(156660.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1315, 91, N'Ram 700', CAST(220046.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1316, 104, N'ELF 100', CAST(299800.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1317, 71, N'GF60', CAST(152850.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1318, 101, N'Giulia', CAST(1187400.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1319, 117, N'X65', CAST(343880.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1320, 89, N'Expert', CAST(403700.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1321, 89, N'Expert Van', CAST(469750.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1322, 89, N'Traveller', CAST(682200.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1323, 100, N'XC40', CAST(684950.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1324, 101, N'Stelvio', CAST(1456666.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1325, 63, N'Q8', CAST(1449900.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1326, 117, N'X35', CAST(288900.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1327, 65, N'X2', CAST(652400.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1328, 65, N'X7', CAST(1769900.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1329, 67, N'XT4', CAST(746500.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1330, 119, N'Serie 300', CAST(811452.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1331, 76, N'BRV', CAST(333900.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1332, 76, N'Insight', CAST(549900.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1333, 77, N'QX50', CAST(821233.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1334, 118, N'Frison', CAST(364000.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1335, 118, N'J4', CAST(214000.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1336, 118, N'SEI7', CAST(506500.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1337, 78, N'E Pace', CAST(1111564.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1338, 78, N'I Pace', CAST(2250375.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1339, 81, N'Velar', CAST(1252681.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1340, 82, N'Nautilus', CAST(951600.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1341, 87, N'Eclipse Cross', CAST(429950.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1342, 89, N'5008', CAST(661566.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1343, 89, N'Rifter', CAST(339900.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1344, 92, N'Oroch', CAST(310900.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1345, 97, N'Ertiga', CAST(288323.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1346, 99, N'Teramont', CAST(788398.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1347, 92, N'Kwid', CAST(181566.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1348, 99, N'Virtus', CAST(321600.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1349, 122, N'MX2', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1350, 122, N'MX3', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1351, 85, N'CX30', CAST(439900.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1352, 115, N'Seltos', CAST(0.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1353, 68, N'Onix', CAST(270500.00 AS Decimal(30, 2)))
GO
INSERT [dbo].[CatModels] ([idModel], [idBrand], [namee], [averagePrice]) VALUES (1354, 99, N'T-Cross', CAST(0.00 AS Decimal(30, 2)))
GO
SET IDENTITY_INSERT [dbo].[CatModels] OFF
GO
ALTER TABLE [dbo].[CatModels]  WITH CHECK ADD FOREIGN KEY([idBrand])
REFERENCES [dbo].[CatBrands] ([idBrand])
GO
USE [master]
GO
ALTER DATABASE [PruebasDB] SET  READ_WRITE 
GO

use [PruebasDB]
go

create table CatModels(
  idModel int identity not null
  , idBrand int
  , namee varchar(200)
  , averagePrice decimal(30,2)
  , primary key(idModel)
  , foreign key (idBrand) references CatBrands(idBrand)
  )
go



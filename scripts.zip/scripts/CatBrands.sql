use [PruebasDB]
go

create table CatBrands(
  idBrand int identity not null
  , namee varchar(200)
  , averagePrice decimal(30,2)
  , primary key(idBrand )
  )
go



  